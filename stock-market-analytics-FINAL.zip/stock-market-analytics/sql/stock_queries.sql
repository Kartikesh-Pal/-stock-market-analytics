-- ================================================================
-- Stock Market Analytics Engine — SQL Queries
-- Database: PostgreSQL 15+
-- Author  : Kartikesh Pal
-- ================================================================


-- ── 1. Daily price summary per ticker ────────────────────────────────────────
SELECT
    ticker,
    DATE_TRUNC('month', date)           AS month,
    ROUND(AVG(close)::numeric, 2)       AS avg_close,
    ROUND(MIN(close)::numeric, 2)       AS min_close,
    ROUND(MAX(close)::numeric, 2)       AS max_close,
    ROUND(AVG(volume)::numeric, 0)      AS avg_volume,
    ROUND(AVG(daily_return)*100, 4)     AS avg_daily_return_pct
FROM stock_prices
GROUP BY ticker, DATE_TRUNC('month', date)
ORDER BY month DESC, ticker;


-- ── 2. Rolling 30-day volatility (annualised) ─────────────────────────────────
SELECT
    date, ticker, close,
    ROUND(
        STDDEV(daily_return) OVER (
            PARTITION BY ticker
            ORDER BY date
            ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
        ) * SQRT(252) * 100, 4
    ) AS volatility_30d_annualised
FROM stock_prices
ORDER BY ticker, date DESC;


-- ── 3. BUY/SELL signal history ────────────────────────────────────────────────
SELECT
    date, ticker, close,
    rsi, macd, macd_signal, golden_cross,
    combined_signal,
    ROUND(ml_prob * 100, 2) AS ml_confidence_pct
FROM stock_signals
WHERE combined_signal IN ('BUY','SELL')
ORDER BY date DESC, ticker;


-- ── 4. Portfolio performance summary ─────────────────────────────────────────
SELECT
    ticker,
    ROUND(
        (LAST_VALUE(close) OVER w - FIRST_VALUE(close) OVER w)
        / NULLIF(FIRST_VALUE(close) OVER w, 0) * 100, 2
    ) AS ytd_return_pct,
    ROUND(AVG(daily_return) OVER w * 252 * 100, 2) AS ann_return_pct,
    ROUND(STDDEV(daily_return) OVER w * SQRT(252) * 100, 2) AS ann_vol_pct,
    ROUND(
        (AVG(daily_return) OVER w * 252 - 0.05)
        / NULLIF(STDDEV(daily_return) OVER w * SQRT(252), 0), 4
    ) AS sharpe_ratio
FROM stock_prices
WINDOW w AS (
    PARTITION BY ticker
    ORDER BY date
    ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
)
GROUP BY ticker, date, close, daily_return
ORDER BY sharpe_ratio DESC;


-- ── 5. Monthly returns heatmap data ──────────────────────────────────────────
SELECT
    ticker,
    EXTRACT(YEAR  FROM date) AS year,
    EXTRACT(MONTH FROM date) AS month,
    ROUND(SUM(daily_return) * 100, 2) AS monthly_return_pct
FROM stock_prices
GROUP BY ticker, year, month
ORDER BY ticker, year, month;


-- ── 6. Top signals this week ──────────────────────────────────────────────────
SELECT
    s.date,
    s.ticker,
    p.close,
    s.combined_signal,
    ROUND(s.ml_prob * 100, 1) AS ml_confidence_pct,
    p.rsi,
    p.macd,
    p.golden_cross
FROM stock_signals s
JOIN stock_prices  p ON s.ticker = p.ticker AND s.date = p.date
WHERE s.date >= CURRENT_DATE - INTERVAL '7 days'
  AND s.combined_signal != 'HOLD'
ORDER BY s.date DESC, s.ml_prob DESC;


-- ── 7. Correlation matrix query ───────────────────────────────────────────────
-- Run in pandas: df.pivot_table(index='date',columns='ticker',values='daily_return').corr()
-- Or via SQL cross-join for small ticker sets:
SELECT
    a.ticker AS ticker_1,
    b.ticker AS ticker_2,
    ROUND(CORR(a.daily_return, b.daily_return)::numeric, 4) AS correlation
FROM stock_prices a
JOIN stock_prices b USING (date)
WHERE a.ticker < b.ticker    -- avoid duplicate pairs
  AND a.date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY a.ticker, b.ticker
ORDER BY correlation DESC;
