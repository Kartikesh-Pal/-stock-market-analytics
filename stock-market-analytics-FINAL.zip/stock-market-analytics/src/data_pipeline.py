"""
================================================================
Stock Market Analytics Engine — Data Pipeline
================================================================
Author  : Kartikesh Pal
Project : Stock Market Analytics & Prediction
Tools   : Python · yfinance · pandas · SQLAlchemy · PostgreSQL
Stocks  : AAPL, MSFT, NVDA, GOOGL, JPM, AMZN
================================================================
"""

import os
import logging
import warnings
import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime, timedelta
from sqlalchemy import create_engine

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
TICKERS  = ["AAPL", "MSFT", "NVDA", "GOOGL", "JPM", "AMZN"]
DB_URL   = os.getenv("DATABASE_URL", "postgresql://user:pass@localhost/stocks_db")
DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")


# ── Fetch Live Data ───────────────────────────────────────────────────────────
def fetch_stock_data(tickers: list = TICKERS, period: str = "2y") -> pd.DataFrame:
    """
    Fetch OHLCV data from Yahoo Finance via yfinance API.

    Args:
        tickers : List of stock ticker symbols
        period  : Data period — '1y', '2y', '5y', 'max'

    Returns:
        Combined DataFrame with all tickers
    """
    log.info(f"Fetching data for {len(tickers)} tickers: {tickers}")
    frames = []
    for ticker in tickers:
        try:
            df = yf.download(ticker, period=period, auto_adjust=True, progress=False)
            if df.empty:
                log.warning(f"No data returned for {ticker}")
                continue
            df["Ticker"] = ticker
            df = df.reset_index()
            frames.append(df)
            log.info(f"  {ticker}: {len(df)} rows ({df['Date'].min().date()} → {df['Date'].max().date()})")
        except Exception as e:
            log.error(f"Failed to fetch {ticker}: {e}")

    combined = pd.concat(frames, ignore_index=True)
    log.info(f"Total rows fetched: {len(combined):,}")
    return combined


def fetch_market_index(period: str = "2y") -> pd.DataFrame:
    """Fetch S&P 500 benchmark data for comparison."""
    sp500 = yf.download("^GSPC", period=period, auto_adjust=True, progress=False)
    sp500 = sp500.reset_index()
    sp500["Ticker"] = "SP500"
    return sp500[["Date", "Close", "Volume", "Ticker"]].rename(columns={"Close": "SP500_Close"})


# ── Clean ─────────────────────────────────────────────────────────────────────
def clean_pipeline(df: pd.DataFrame) -> pd.DataFrame:
    """
    Standard data cleaning pipeline.
    - Remove duplicates
    - Forward-fill missing OHLCV values
    - Sort by Ticker + Date
    - Compute daily returns
    """
    initial = len(df)
    df = df.drop_duplicates(subset=["Date", "Ticker"])
    df = df.sort_values(["Ticker", "Date"]).reset_index(drop=True)

    ohlcv = ["Open", "High", "Low", "Close", "Volume"]
    for col in ohlcv:
        if col in df.columns:
            df[col] = df.groupby("Ticker")[col].ffill()

    df["Daily_Return"]   = df.groupby("Ticker")["Close"].pct_change()
    df["Log_Return"]     = np.log(df["Close"] / df.groupby("Ticker")["Close"].shift(1))
    df["Price_Range"]    = df["High"] - df["Low"]
    df["Typical_Price"]  = (df["High"] + df["Low"] + df["Close"]) / 3

    df = df.dropna(subset=["Close"])
    log.info(f"Cleaned: {initial} → {len(df)} rows")
    return df


# ── Validate ──────────────────────────────────────────────────────────────────
def validate_data(df: pd.DataFrame) -> dict:
    """Generate data quality report."""
    report = {
        "total_rows"     : len(df),
        "tickers"        : df["Ticker"].unique().tolist(),
        "date_range"     : f"{df['Date'].min().date()} → {df['Date'].max().date()}",
        "missing_pct"    : (df.isnull().sum() / len(df) * 100).round(2).to_dict(),
        "avg_daily_vol"  : df.groupby("Ticker")["Volume"].mean().round(0).to_dict(),
        "price_range"    : df.groupby("Ticker")["Close"].agg(["min", "max"]).to_dict(),
    }
    log.info(f"Data Quality: {report['total_rows']:,} rows | {len(report['tickers'])} tickers | {report['date_range']}")
    return report


# ── Save ──────────────────────────────────────────────────────────────────────
def save_to_csv(df: pd.DataFrame, name: str = "stock_data_clean.csv"):
    path = os.path.join(DATA_DIR, "processed", name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    df.to_csv(path, index=False)
    log.info(f"Saved → {path}")
    return path


def push_to_db(df: pd.DataFrame, table: str = "stock_prices"):
    """Push cleaned data to PostgreSQL database."""
    try:
        engine = create_engine(DB_URL)
        df.to_sql(table, engine, if_exists="replace", index=False, chunksize=1000)
        log.info(f"Pushed {len(df):,} rows → table: {table}")
    except Exception as e:
        log.warning(f"DB push skipped (configure DATABASE_URL in .env): {e}")


# ── Simulate (offline mode) ───────────────────────────────────────────────────
def generate_sample_data(tickers: list = TICKERS, days: int = 504) -> pd.DataFrame:
    """
    Generate realistic synthetic OHLCV data for offline demo.
    Uses geometric Brownian motion to simulate stock prices.
    In production, replace with fetch_stock_data().
    """
    np.random.seed(42)
    start_prices = {"AAPL":150,"MSFT":300,"NVDA":400,"GOOGL":120,"JPM":150,"AMZN":130}
    dates = pd.bdate_range(end=datetime.today(), periods=days)
    frames = []
    for ticker in tickers:
        s0  = start_prices.get(ticker, 100)
        mu  = 0.0003
        sig = 0.018
        rets = np.random.normal(mu, sig, days)
        prices = s0 * np.exp(np.cumsum(rets))
        high   = prices * np.random.uniform(1.001, 1.025, days)
        low    = prices * np.random.uniform(0.975, 0.999, days)
        open_  = prices * np.random.uniform(0.995, 1.005, days)
        vol    = np.random.lognormal(16, 0.5, days).astype(int)
        df = pd.DataFrame({
            "Date": dates, "Ticker": ticker,
            "Open": open_.round(2), "High": high.round(2),
            "Low": low.round(2), "Close": prices.round(2), "Volume": vol
        })
        frames.append(df)
    return pd.concat(frames, ignore_index=True)


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    log.info("Starting data pipeline...")
    try:
        raw = fetch_stock_data(TICKERS, period="2y")
    except Exception as e:
        log.warning(f"Live fetch failed ({e}) — using simulated data")
        raw = generate_sample_data(TICKERS)

    clean  = clean_pipeline(raw)
    report = validate_data(clean)
    save_to_csv(clean)
    push_to_db(clean)

    print("\n✅ Data Pipeline Complete")
    print(f"   Tickers    : {report['tickers']}")
    print(f"   Date Range : {report['date_range']}")
    print(f"   Total Rows : {report['total_rows']:,}")
