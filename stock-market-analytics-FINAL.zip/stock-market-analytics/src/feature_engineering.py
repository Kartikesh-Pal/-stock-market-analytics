"""
================================================================
Stock Market Analytics Engine — Feature Engineering
================================================================
Author  : Kartikesh Pal
Project : Stock Market Analytics & Prediction
Tools   : Python · pandas · NumPy · TA-Lib
Indicators: RSI, MACD, Bollinger Bands, ATR, SMA, EMA,
            Golden Cross, Stochastic Oscillator, OBV
================================================================
"""

import logging
import pandas as pd
import numpy as np

log = logging.getLogger(__name__)


# ── RSI ───────────────────────────────────────────────────────────────────────
def compute_rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """
    Relative Strength Index (RSI) — Wilder (1978).
    Measures momentum: RSI > 70 = overbought, RSI < 30 = oversold.
    Range: 0–100.
    """
    delta = series.diff()
    gain  = delta.clip(lower=0).rolling(window=period).mean()
    loss  = (-delta.clip(upper=0)).rolling(window=period).mean()
    rs    = gain / loss.replace(0, np.nan)
    return (100 - (100 / (1 + rs))).round(4)


# ── MACD ──────────────────────────────────────────────────────────────────────
def compute_macd(series: pd.Series,
                 fast: int = 12, slow: int = 26, signal: int = 9):
    """
    Moving Average Convergence Divergence (MACD).
    MACD line > Signal line = bullish momentum.
    Returns: (macd_line, signal_line, histogram)
    """
    ema_fast   = series.ewm(span=fast,   adjust=False).mean()
    ema_slow   = series.ewm(span=slow,   adjust=False).mean()
    macd_line  = ema_fast - ema_slow
    signal_line= macd_line.ewm(span=signal, adjust=False).mean()
    histogram  = macd_line - signal_line
    return macd_line.round(4), signal_line.round(4), histogram.round(4)


# ── Bollinger Bands ───────────────────────────────────────────────────────────
def compute_bollinger_bands(series: pd.Series, window: int = 20, n_std: float = 2.0):
    """
    Bollinger Bands — John Bollinger (1980s).
    Upper / Middle (SMA) / Lower bands.
    Squeeze (narrow bands) → potential breakout signal.
    Returns: (upper, middle, lower, bandwidth, %B)
    """
    middle    = series.rolling(window).mean()
    std       = series.rolling(window).std()
    upper     = middle + n_std * std
    lower     = middle - n_std * std
    bandwidth = ((upper - lower) / middle * 100).round(4)
    pct_b     = ((series - lower) / (upper - lower)).round(4)
    return upper.round(4), middle.round(4), lower.round(4), bandwidth, pct_b


# ── ATR ───────────────────────────────────────────────────────────────────────
def compute_atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    """
    Average True Range (ATR) — Wilder (1978).
    Measures market volatility. High ATR = high volatility.
    """
    prev_close = close.shift(1)
    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low  - prev_close).abs()
    ], axis=1).max(axis=1)
    return tr.rolling(period).mean().round(4)


# ── Moving Averages ───────────────────────────────────────────────────────────
def compute_moving_averages(series: pd.Series) -> dict:
    """Compute SMA and EMA for multiple periods."""
    return {
        "SMA_10" : series.rolling(10).mean().round(4),
        "SMA_20" : series.rolling(20).mean().round(4),
        "SMA_50" : series.rolling(50).mean().round(4),
        "SMA_200": series.rolling(200).mean().round(4),
        "EMA_12" : series.ewm(span=12, adjust=False).mean().round(4),
        "EMA_26" : series.ewm(span=26, adjust=False).mean().round(4),
        "EMA_50" : series.ewm(span=50, adjust=False).mean().round(4),
    }


# ── Golden / Death Cross ──────────────────────────────────────────────────────
def compute_golden_cross(sma50: pd.Series, sma200: pd.Series) -> pd.Series:
    """
    Golden Cross: SMA50 crosses above SMA200 → bullish long-term signal.
    Death Cross : SMA50 crosses below SMA200 → bearish signal.
    Returns: 1 = Golden Cross active, 0 = Death Cross / no signal.
    """
    return (sma50 > sma200).astype(int)


# ── Stochastic Oscillator ─────────────────────────────────────────────────────
def compute_stochastic(high: pd.Series, low: pd.Series, close: pd.Series,
                        k_period: int = 14, d_period: int = 3):
    """
    Stochastic Oscillator — George Lane.
    %K > 80 = overbought, %K < 20 = oversold.
    Returns: (%K, %D)
    """
    lowest_low   = low.rolling(k_period).min()
    highest_high = high.rolling(k_period).max()
    pct_k = ((close - lowest_low) / (highest_high - lowest_low) * 100).round(4)
    pct_d = pct_k.rolling(d_period).mean().round(4)
    return pct_k, pct_d


# ── OBV ───────────────────────────────────────────────────────────────────────
def compute_obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    """
    On-Balance Volume (OBV) — Joseph Granville.
    Rising OBV + rising price = strong uptrend confirmation.
    """
    direction = np.sign(close.diff()).fillna(0)
    return (direction * volume).cumsum()


# ── Volatility ────────────────────────────────────────────────────────────────
def compute_volatility(returns: pd.Series, window: int = 21) -> pd.Series:
    """Annualised rolling volatility (standard deviation of returns × √252)."""
    return (returns.rolling(window).std() * np.sqrt(252)).round(4)


# ── Master Function ───────────────────────────────────────────────────────────
def add_all_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute all 8+ technical indicators for every stock in the DataFrame.
    Groups by Ticker to avoid cross-contamination between stocks.
    """
    log.info("Computing technical indicators for all tickers...")
    dfs = []

    for ticker, group in df.groupby("Ticker"):
        g = group.copy().sort_values("Date").reset_index(drop=True)
        close  = g["Close"]
        high   = g["High"]
        low    = g["Low"]
        volume = g["Volume"]
        ret    = g["Daily_Return"] if "Daily_Return" in g.columns else close.pct_change()

        # RSI
        g["RSI"] = compute_rsi(close)

        # MACD
        g["MACD"], g["MACD_Signal"], g["MACD_Hist"] = compute_macd(close)
        g["MACD_Cross"] = (g["MACD"] > g["MACD_Signal"]).astype(int)

        # Bollinger Bands
        g["BB_Upper"], g["BB_Mid"], g["BB_Lower"], g["BB_Width"], g["BB_PctB"] = \
            compute_bollinger_bands(close)

        # ATR
        g["ATR"] = compute_atr(high, low, close)

        # Moving Averages
        mas = compute_moving_averages(close)
        for name, series in mas.items():
            g[name] = series

        # Golden Cross
        if "SMA_50" in g.columns and "SMA_200" in g.columns:
            g["Golden_Cross"] = compute_golden_cross(g["SMA_50"], g["SMA_200"])

        # Stochastic
        g["Stoch_K"], g["Stoch_D"] = compute_stochastic(high, low, close)

        # OBV
        g["OBV"] = compute_obv(close, volume)

        # Volatility
        g["Volatility_21d"] = compute_volatility(ret)

        # Price position vs SMA
        if "SMA_50" in g.columns:
            g["Price_Above_SMA50"] = (close > g["SMA_50"]).astype(int)

        # Momentum
        g["Momentum_10d"] = close.pct_change(10).round(4)
        g["Momentum_30d"] = close.pct_change(30).round(4)

        dfs.append(g)

    result = pd.concat(dfs, ignore_index=True)
    log.info(f"Features computed: {result.shape[1]} columns for {result['Ticker'].nunique()} tickers")
    return result


# ── Feature Summary ───────────────────────────────────────────────────────────
def feature_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Summary statistics of all technical indicator columns."""
    indicator_cols = [
        "RSI", "MACD", "ATR", "BB_Width", "Stoch_K",
        "Volatility_21d", "Momentum_10d", "Momentum_30d"
    ]
    available = [c for c in indicator_cols if c in df.columns]
    return df.groupby("Ticker")[available].mean().round(4)


# ── Signal Generation ─────────────────────────────────────────────────────────
def generate_rule_signals(df: pd.DataFrame) -> pd.DataFrame:
    """
    Rule-based trading signal from technical indicators.
    BUY  : RSI 40–70 + MACD bullish + Golden Cross + Price > SMA50
    SELL : RSI > 75 OR (MACD bearish + RSI < 35)
    HOLD : otherwise
    """
    df = df.copy()
    buy_cond = (
        df["RSI"].between(40, 70) &
        (df["MACD"] > df["MACD_Signal"]) &
        (df["Golden_Cross"] == 1) &
        (df["Price_Above_SMA50"] == 1)
    )
    sell_cond = (
        (df["RSI"] > 75) |
        ((df["MACD"] < df["MACD_Signal"]) & (df["RSI"] < 35))
    )
    df["Signal"] = "HOLD"
    df.loc[buy_cond,  "Signal"] = "BUY"
    df.loc[sell_cond, "Signal"] = "SELL"
    signal_counts = df.groupby(["Ticker", "Signal"]).size().unstack(fill_value=0)
    log.info(f"Signals generated:\n{signal_counts}")
    return df


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.dirname(__file__))
    from data_pipeline import generate_sample_data, clean_pipeline

    raw   = generate_sample_data()
    clean = clean_pipeline(raw)
    df    = add_all_features(clean)
    df    = generate_rule_signals(df)

    print("\n── Feature Summary ────────────────────────────────────")
    print(feature_summary(df).to_string())

    print("\n── Signal Distribution ────────────────────────────────")
    print(df.groupby(["Ticker","Signal"]).size().unstack(fill_value=0))

    print("\n── Sample AAPL ────────────────────────────────────────")
    aapl = df[df["Ticker"]=="AAPL"].tail(5)
    cols = ["Date","Close","RSI","MACD","ATR","Golden_Cross","Signal"]
    print(aapl[cols].to_string(index=False))
