"""
================================================================
Stock Market Analytics Engine — Visualization Suite
================================================================
Author  : Kartikesh Pal
Project : Stock Market Analytics & Prediction
Tools   : Matplotlib · Seaborn · Plotly
Charts  : Candlestick, Performance, RSI, MACD, Heatmap,
          Correlation Matrix, Feature Importance, Risk-Return
================================================================
"""

import os
import logging
import warnings
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)

OUT_DIR = "output_charts"
os.makedirs(OUT_DIR, exist_ok=True)

# ── Style ─────────────────────────────────────────────────────────────────────
PALETTE = {
    "navy"  : "#1a3a5c",
    "cyan"  : "#00d4ff",
    "green" : "#10b981",
    "red"   : "#ef4444",
    "amber" : "#f59e0b",
    "muted" : "#6b7280",
    "light" : "#f9fafb",
}
sns.set_theme(style="whitegrid")


def _apply_style(ax, title="", xlabel="", ylabel=""):
    ax.set_title(title, fontsize=13, fontweight="bold", color=PALETTE["navy"], pad=10)
    ax.set_xlabel(xlabel, fontsize=9, color=PALETTE["muted"])
    ax.set_ylabel(ylabel, fontsize=9, color=PALETTE["muted"])
    ax.tick_params(colors=PALETTE["muted"], labelsize=8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def _save(filename: str):
    path = os.path.join(OUT_DIR, filename)
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
    log.info(f"Saved → {path}")
    plt.close()


# ── 1. YTD Performance Line Chart ─────────────────────────────────────────────
def plot_ytd_performance(df: pd.DataFrame):
    """Normalised YTD performance of all stocks vs S&P 500."""
    fig, ax = plt.subplots(figsize=(13, 5))
    colors  = [PALETTE["navy"], PALETTE["cyan"], PALETTE["green"],
               PALETTE["red"],  PALETTE["amber"], "#8b5cf6"]

    for i, (ticker, group) in enumerate(df.groupby("Ticker")):
        g      = group.sort_values("Date")
        norm   = g["Close"] / g["Close"].iloc[0] * 100
        ax.plot(g["Date"], norm, linewidth=2,
                color=colors[i % len(colors)], label=ticker)

    ax.axhline(100, color=PALETTE["muted"], linestyle="--", linewidth=0.8)
    _apply_style(ax, "YTD Normalised Performance (Base = 100)",
                 "Date", "Indexed Price")
    ax.legend(fontsize=9, frameon=True)
    ax.yaxis.set_major_formatter(mtick.FuncFormatter(lambda x, _: f"{x:.0f}"))
    plt.tight_layout()
    _save("ytd_performance.png")


# ── 2. Candlestick Chart (Plotly) ─────────────────────────────────────────────
def plot_candlestick(df: pd.DataFrame, ticker: str = "AAPL", days: int = 90):
    """Interactive candlestick with SMA overlay — saved as HTML."""
    data = df[df["Ticker"] == ticker].sort_values("Date").tail(days)

    fig = make_subplots(rows=2, cols=1, shared_xaxes=True,
                        row_heights=[0.7, 0.3], vertical_spacing=0.05)
    fig.add_trace(go.Candlestick(
        x=data["Date"], open=data["Open"], high=data["High"],
        low=data["Low"], close=data["Close"], name=ticker,
        increasing_line_color=PALETTE["green"],
        decreasing_line_color=PALETTE["red"]
    ), row=1, col=1)

    for col, color, name in [("SMA_20","#f59e0b","SMA 20"),
                              ("SMA_50","#3b82f6","SMA 50")]:
        if col in data.columns:
            fig.add_trace(go.Scatter(x=data["Date"], y=data[col],
                line=dict(color=color, width=1.5, dash="dash"),
                name=name), row=1, col=1)

    fig.add_trace(go.Bar(x=data["Date"], y=data["Volume"],
                         name="Volume", marker_color=PALETTE["muted"],
                         opacity=0.6), row=2, col=1)

    fig.update_layout(
        title=f"{ticker} — Candlestick Chart ({days} days)",
        title_font_color=PALETTE["navy"], title_font_size=14,
        template="plotly_white", xaxis_rangeslider_visible=False,
        height=550, legend=dict(orientation="h", y=1.02)
    )
    path = os.path.join(OUT_DIR, f"candlestick_{ticker}.html")
    fig.write_html(path)
    log.info(f"Saved → {path}")
    return fig


# ── 3. RSI Chart ──────────────────────────────────────────────────────────────
def plot_rsi(df: pd.DataFrame, ticker: str = "AAPL"):
    """RSI with overbought/oversold zones."""
    data = df[df["Ticker"] == ticker].sort_values("Date").tail(120)
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(13, 7), sharex=True)

    ax1.plot(data["Date"], data["Close"], color=PALETTE["navy"], linewidth=2)
    _apply_style(ax1, f"{ticker} — Price & RSI", ylabel="Price ($)")

    ax2.plot(data["Date"], data["RSI"], color=PALETTE["cyan"], linewidth=2)
    ax2.axhline(70, color=PALETTE["red"],   linestyle="--", linewidth=1.2, label="Overbought (70)")
    ax2.axhline(30, color=PALETTE["green"], linestyle="--", linewidth=1.2, label="Oversold (30)")
    ax2.fill_between(data["Date"], data["RSI"], 70,
                     where=data["RSI"] > 70, alpha=0.15, color=PALETTE["red"])
    ax2.fill_between(data["Date"], data["RSI"], 30,
                     where=data["RSI"] < 30, alpha=0.15, color=PALETTE["green"])
    _apply_style(ax2, "", xlabel="Date", ylabel="RSI")
    ax2.set_ylim(0, 100)
    ax2.legend(fontsize=8)

    plt.tight_layout()
    _save(f"rsi_{ticker}.png")


# ── 4. MACD Chart ─────────────────────────────────────────────────────────────
def plot_macd(df: pd.DataFrame, ticker: str = "AAPL"):
    """MACD line + Signal + Histogram."""
    data = df[df["Ticker"] == ticker].sort_values("Date").tail(120)
    fig, ax = plt.subplots(figsize=(13, 4))

    ax.plot(data["Date"], data["MACD"],        color=PALETTE["navy"],  linewidth=2, label="MACD")
    ax.plot(data["Date"], data["MACD_Signal"], color=PALETTE["amber"], linewidth=1.5, label="Signal")
    ax.bar(data["Date"], data["MACD_Hist"],
           color=[PALETTE["green"] if v >= 0 else PALETTE["red"] for v in data["MACD_Hist"]],
           alpha=0.5, label="Histogram", width=1)
    ax.axhline(0, color=PALETTE["muted"], linewidth=0.8)

    _apply_style(ax, f"{ticker} — MACD Indicator", "Date", "MACD Value")
    ax.legend(fontsize=9)
    plt.tight_layout()
    _save(f"macd_{ticker}.png")


# ── 5. Correlation Heatmap ────────────────────────────────────────────────────
def plot_correlation_heatmap(df: pd.DataFrame):
    """Pairwise stock return correlation matrix."""
    pivot = df.pivot_table(index="Date", columns="Ticker", values="Daily_Return")
    corr  = pivot.corr()

    fig, ax = plt.subplots(figsize=(9, 7))
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(corr, mask=mask, annot=True, fmt=".2f",
                cmap="RdBu_r", center=0, vmin=-1, vmax=1,
                linewidths=0.5, linecolor="white", ax=ax,
                cbar_kws={"shrink": 0.8})
    _apply_style(ax, "Stock Return Correlation Matrix")
    plt.tight_layout()
    _save("correlation_heatmap.png")


# ── 6. Monthly Returns Heatmap ────────────────────────────────────────────────
def plot_monthly_returns(df: pd.DataFrame, ticker: str = "AAPL"):
    """Monthly return heatmap — calendar view."""
    data = df[df["Ticker"] == ticker].copy()
    data["Year"]  = pd.to_datetime(data["Date"]).dt.year
    data["Month"] = pd.to_datetime(data["Date"]).dt.month

    monthly = data.groupby(["Year","Month"])["Daily_Return"].sum().reset_index()
    monthly["Return_Pct"] = monthly["Daily_Return"] * 100
    pivot = monthly.pivot(index="Year", columns="Month", values="Return_Pct")
    pivot.columns = ["Jan","Feb","Mar","Apr","May","Jun",
                     "Jul","Aug","Sep","Oct","Nov","Dec"][:len(pivot.columns)]

    fig, ax = plt.subplots(figsize=(13, max(3, len(pivot) * 0.9)))
    sns.heatmap(pivot, annot=True, fmt=".1f", cmap="RdYlGn",
                center=0, linewidths=0.5, linecolor="white",
                ax=ax, cbar_kws={"label": "Monthly Return (%)"})
    _apply_style(ax, f"{ticker} — Monthly Returns Heatmap (%)")
    plt.tight_layout()
    _save(f"monthly_returns_{ticker}.png")


# ── 7. Risk-Return Scatter ────────────────────────────────────────────────────
def plot_risk_return(df: pd.DataFrame):
    """Risk vs Return scatter plot for all tickers."""
    stats = []
    for ticker, g in df.groupby("Ticker"):
        ret = g["Daily_Return"].dropna()
        stats.append({
            "Ticker"      : ticker,
            "Ann_Return"  : ret.mean() * 252 * 100,
            "Ann_Vol"     : ret.std() * np.sqrt(252) * 100,
            "Avg_Volume"  : g["Volume"].mean(),
        })
    stats_df = pd.DataFrame(stats)

    fig, ax = plt.subplots(figsize=(9, 6))
    colors = [PALETTE["navy"], PALETTE["cyan"], PALETTE["green"],
              PALETTE["red"], PALETTE["amber"], "#8b5cf6"]

    for i, row in stats_df.iterrows():
        ax.scatter(row["Ann_Vol"], row["Ann_Return"],
                   s=180, color=colors[i % len(colors)],
                   zorder=5, edgecolors="white", linewidth=1)
        ax.annotate(row["Ticker"], (row["Ann_Vol"] + 0.3, row["Ann_Return"]),
                    fontsize=10, fontweight="bold", color=PALETTE["navy"])

    ax.axhline(0, color=PALETTE["muted"], linewidth=0.8, linestyle="--")
    _apply_style(ax, "Risk-Return Profile — All Tickers",
                 "Annualised Volatility (%)", "Annualised Return (%)")
    plt.tight_layout()
    _save("risk_return_scatter.png")


# ── 8. Feature Importance ─────────────────────────────────────────────────────
def plot_feature_importance(fi_df: pd.DataFrame):
    """Horizontal bar chart of XGBoost feature importances."""
    top = fi_df.head(12).sort_values("importance")
    fig, ax = plt.subplots(figsize=(9, 6))
    bars = ax.barh(top["feature"], top["importance"],
                   color=PALETTE["navy"], alpha=0.85, edgecolor="white")
    for bar, val in zip(bars, top["importance"]):
        ax.text(bar.get_width() + 0.002, bar.get_y() + bar.get_height()/2,
                f"{val:.4f}", va="center", fontsize=8, color=PALETTE["muted"])
    _apply_style(ax, "XGBoost Feature Importance (Top 12)",
                 "Importance Score", "Feature")
    plt.tight_layout()
    _save("feature_importance.png")


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    sys.path.insert(0, os.path.dirname(__file__))
    from data_pipeline      import generate_sample_data, clean_pipeline
    from feature_engineering import add_all_features
    from ml_model            import train_and_evaluate, feature_importance_report, build_target

    raw     = generate_sample_data()
    clean   = clean_pipeline(raw)
    df      = add_all_features(clean)

    plot_ytd_performance(df)
    plot_rsi(df, "AAPL")
    plot_macd(df, "AAPL")
    plot_correlation_heatmap(df)
    plot_monthly_returns(df, "AAPL")
    plot_risk_return(df)
    plot_candlestick(df, "AAPL")

    # Feature importance
    df_model = build_target(df)
    results  = train_and_evaluate(df_model)
    fi       = feature_importance_report(results["model"], results["feature_names"])
    plot_feature_importance(fi)

    print(f"\n✅ All charts saved to {OUT_DIR}/")
